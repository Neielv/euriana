<!DOCTYPE html>
<html lang="en">
    <head>
    </head>
    <body>
        <h1>BIORMED - NUEVO PEDIDO</h1>
        <div>
            <h1>Orden: {{$codigo}}</h1>
            Vendedor: {{$vendedor}} <br>
            Cliente: {{$cliente}} <br>
            Total (USD): {{$total}} <br>
        </div>
        <div>
            Para mayor información inngrese a; <a href="http://app.biormed.com.ec/">http://app.biormed.com.ec/</a>
        </div>
    </body>
</html>
