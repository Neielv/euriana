<!DOCTYPE html>
<html lang="en">
    <head>
    </head>
    <body>
        <h1>BIORMED - NUEVO PEDIDO</h1>
        <div>
            <h1>Orden: <?php echo e($codigo); ?></h1>
            Vendedor: <?php echo e($vendedor); ?> <br>
            Cliente: <?php echo e($cliente); ?> <br>
            Total (USD): <?php echo e($total); ?> <br>
        </div>
        <div>
            Para mayor información inngrese a; <a href="http://app.biormed.com.ec/">http://app.biormed.com.ec/</a>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\biormed\resources\views/emails/NuevaOrden.blade.php ENDPATH**/ ?>