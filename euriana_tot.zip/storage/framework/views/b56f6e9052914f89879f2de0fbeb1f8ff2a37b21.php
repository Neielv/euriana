<!DOCTYPE html>
<html lang="es">
    <head>
        <title>Biormer-reportes</title>
    </head>
    <body>
        HOLA
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/descarga-reportes.blade.php ENDPATH**/ ?>