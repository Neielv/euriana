<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <div style="float: right;">
            <img src= "./images/biormed_logo.jpg" width="200">
            </div>
      <h3>BIORMED</h3>
          <h3>  Nota de pedido</h3>          
    <hr/>
    
    <table>
        <tr>
            <td><strong> Nro: </strong>  <?php echo e($datos->id); ?> </td>            
        </tr>
        <tr>            
            <td><strong> Fecha: </strong> <?php echo e($fecha); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> Cédula/Ruc: </strong> <?php echo e($cedula); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> Cliente: </strong> <?php echo e($cliente); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> Teléfono: </strong> <?php echo e($telefono); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> email: </strong> <?php echo e($email); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> Nota de devolución: </strong> <?php echo e($devolucion); ?>

            </td>
        </tr>
        <tr>            
            <td><strong> Factura: </strong> <?php echo e($factura); ?>

            </td>
        </tr>
    </table><br/><br/>
    <table style="border: 1px solid black;  border-collapse: collapse;">
        <tr style="border: 1px solid black;">            
            <td style="border: 1px solid black;"><strong> Cantidad </strong></td>
                    
            <td style="border: 1px solid black;"><strong> Porducto </strong></td>
                  
            <td style="border: 1px solid black;"><strong> Precio </strong></td>
                   
            <td style="border: 1px solid black;"><strong> Subtotal </strong></td>
        </tr>
        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td style="border: 1px solid black;"><?php echo e($item['cantidad']); ?></td>
             <td style="border: 1px solid black;"><?php echo e($item['nombre']); ?></td>
             <td style="border: 1px solid black;"><?php echo e($item['precio']); ?></td>
             <td style="border: 1px solid black;"><?php echo e($item['subtotal']); ?></td>                                                        
         </tr>                           
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td colspan="3" style="text-align:right; padding-right: 22px; "><strong> Subtotal</strong></td>
            <td style="text-align:left; margin-right: 8px; border: 1px solid black;">USD <?php echo e($subtotal); ?></td>
        </tr>
        <tr>
            <td colspan="3" style="text-align:right; padding-right: 22px;"><strong>Iva</strong></td>
            <td style="text-align:left; margin-right: 8px; border: 1px solid black;">USD <?php echo e($iva); ?></td>
        </tr>
        <tr>
            <td colspan="3" style="text-align:right; padding-right: 22px;"><strong>Total</strong></td>
            <td style="text-align:left; margin-right: 8px; border: 1px solid black;">USD <?php echo e($total); ?></td>
        </tr>
    </table>
 </body>
    
   
</html><?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/pdf.blade.php ENDPATH**/ ?>