<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <div style="float: right;">
            <img src= "./images/biormed_logo.jpg" width="200">
            </div>
      <h3>BIORMED</h3>
       <h3>REPORTE CONSOLIDADO POR <?php echo e($tipo); ?></h3>          
    <hr/>
    
 
   
   <table style="border: 1px solid black;  border-collapse: collapse;">
    <tr style="border: 1px solid black;">            
        <td style="border: 1px solid black;"><strong> idPedido </strong></td>
                
        <td style="border: 1px solid black;"><strong> Cliente </strong></td>
              
        <td style="border: 1px solid black;"><strong> Subtotal </strong></td>
               
        <td style="border: 1px solid black;"><strong> Total </strong></td>

        <td style="border: 1px solid black;"><strong> Estado </strong></td>


        <td style="border: 1px solid black;"><strong> Cantidad </strong></td>


        
     <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
        <td style="border: 1px solid black;"><?php echo e($item['id']); ?></td>
        <td style="border: 1px solid black;"><?php echo e($item['nombre']); ?></td>
        <td style="border: 1px solid black;"><?php echo e($item['subtotal']); ?></td>
        <td style="border: 1px solid black;"><?php echo e($item['total']); ?></td> 
        <td style="border: 1px solid black;"><?php echo e($item['nombre_estado']); ?></td> 
        <td style="border: 1px solid black;"><?php echo e($item['cantidad']); ?></td>   
                                             
     </tr>                           
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
</table>
    
 </body>
    
   
</html><?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/consolidadoProducto.blade.php ENDPATH**/ ?>