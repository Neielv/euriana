<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Nuevo Pedido')); ?>

        </h2>
     <?php $__env->endSlot(); ?>



    <div class="min-h-screen  items-center justify-center bg-gray-50 py-1 px-4 sm:px-6 lg:px-8">



        <div class="shadow sm:rounded-md sm:overflow-hidden">
            <div class="px-4 py-5 bg-white space-y-6 sm:p-6">
                <div class="grid grid-cols-3 gap-6">
                    <div class="col-span-3 sm:col-span-2">
                        <label for="company-website" class="block text-sm font-medium text-gray-700">
                            Cliente
                        </label>
                        <div class="mt-1 flex rounded-md shadow-sm">
                            <span
                                class="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                                CI.
                            </span>
                            <input wire:model="search" type="text" name="company-website" id="company-website"
                                class="focus:ring-indigo-500 focus:border-indigo-500 flex-1 block w-full rounded-none rounded-r-md sm:text-sm border-gray-300"
                                placeholder="Cédula o nombre">

                            <span class="inline-flex items-center px-3 rounded-l-md   text-gray-500 text-sm">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-cliente')->html();
} elseif ($_instance->childHasBeenRendered('8bN1X7W')) {
    $componentId = $_instance->getRenderedChildComponentId('8bN1X7W');
    $componentTag = $_instance->getRenderedChildComponentTagName('8bN1X7W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8bN1X7W');
} else {
    $response = \Livewire\Livewire::mount('create-cliente');
    $html = $response->html();
    $_instance->logRenderedChild('8bN1X7W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </span>
                        </div>
                    </div>

                </div>

                <!--PEDIDO-->
                <div class="shadow sm:rounded-md sm:overflow-hidden">
                    <!--CABECERA-->
                    <div class="px-4 py-5 bg-white space-y-6 sm:p-6">
                        <div class="grid grid-cols-3 gap-6">
                            <div class="col-span-3 sm:col-span-2">
                                <label for="company-website" class="block text-sm font-medium text-gray-700">
                                    Cliente
                                </label>
                                <?php if($clientes->count() == 1 && $search != ''): ?>
                                    <div class="shadow sm:rounded-md sm:overflow-hidden">
                                        <div class="px-2  flex items-center ">
                                            <div class="px-2  py-1 flex items-center">
                                                Cédula: <?php echo e($clientes[0]->ci); ?>

                                                <?php echo e($clientes_id=$clientes[0]->id); ?>

                                               
                                            </div>
                                        </div>
                                        

                                        <div class="px-2  flex items-center ">
                                            <div class="px-2  py-1 flex items-center">
                                                Nombre: <?php echo e($clientes[0]->nombre); ?>

                                            </div>
                                        </div>

                                        <div class="px-2  flex items-center ">
                                            <div class="px-2  py-1 flex items-center">
                                                Teléfono: <?php echo e($clientes[0]->telefono); ?>

                                            </div>
                                        </div>
                                        <div class="px-2  flex items-center ">
                                            <div class="px-2  py-1 flex items-center">
                                                Tipo: <?php echo e($clientes[0]->tipo->nombre); ?>

                                            </div>
                                        </div>
                                        


                                    </div>
                                <?php else: ?>
                                    <div class="px-2  flex items-center ">
                                        <div class="px-2  py-1 flex items-center">
                                            <?php if($search == ''): ?>
                                                Ingrese el número de cédula o le nombre
                                            <?php else: ?>
                                                Cliente no encontrado
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>

                        </div>


                        <!--SECCION PRODUCTOS-->

                        <div>
                            <label for="about" class="block text-sm font-medium text-gray-700">
                                Producto
                            </label>
                            <div class="shadow sm:rounded-md sm:overflow-hidden ">
                                <div class="px-4 py-5 bg-white space-y-6 sm:p-6 ">
                                    <div class="grid grid-cols-3 gap-6 ">
                                        <div class="col-span-3 sm:col-span-2 ">
                                            <div class="sm:col-span-3 ">
                                                <table>
                                                    <tr>
                                                        <th>
                                                            <td>
                                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => 'Código']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => 'Código']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','wire:model' => 'codigo_producto','style' => 'width: 140px']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','wire:model' => 'codigo_producto','style' => 'width: 140px']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                
                                                            </td>
                                                            <td>
                                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => 'Precio']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => 'Precio']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','wire:model' => 'precio_producto','style' => 'width: 80px','disabled' => 'disabled']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','wire:model' => 'precio_producto','style' => 'width: 80px','disabled' => 'disabled']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => 'Cantidad']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => 'Cantidad']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                                <input wire:model.defer="cantidad"
                                                                type="number"
                                                                class="w-12 border border-gray-300 rounded-md shadow-sm  outline-none focus:outline-none text-center w-30 bg-gray-300   items-center sm:text-sm"
                                                                name="cantidad" maxlength="2" value="0" />
                                                            </td>
                                                        </th>
                                                    </tr>
                                                </table>



                                                



                                                <samp>   

                                                    
                                                       
                                                </samp>
                                                
                                            </div>
                                            <div>
                                                <?php echo e('Cantidad disponible: '. $maximo); ?>

                                            </div>
                                        </div class="my-30">

                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'add']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'add']); ?>
                                            Agregar 
                                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  
                                        </div>
                                        </div>
                                    </div>

                                </div>

                               
                                <!--DETALLE-->

                                <div>
                                    <label class="block text-sm font-medium text-gray-700">
                                        Detalle
                                    </label>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                        <table class="min-w-full divide-y divide-gray-200">
                                            <thead class="bg-gray-50">
                                                <tr>
                                                    <td>
                                                        CANT.
                                                    </td>
                                                    <td>
                                                        PRODUCTO
                                                    </td>
                                                    <td>
                                                        PRECIO
                                                    </td>
                                                    <td>
                                                        SUB TOTAL
                                                    </td>
                                                    <td>
                                                        QUITAR
                                                    </td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                               
                                                <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                    
                                               
                                                 <tr>
                                                     <td><?php echo e($item['cantidad']); ?></td>
                                                     <td><?php echo e($item['nombre']); ?></td>
                                                     <td><?php echo e($item['precio']); ?></td>
                                                     <td><?php echo e($item['subtotal']); ?></td>
                                                     <td class="px-1 py-1 whitespace-nowrap ext-sm font-medium flex">
                                                        <a class="btn btn-red ml-2" wire:click="$emit('quitarProducto',<?php echo e($key); ?>)">
                                                            <i class="fas fa-trash">
                    
                                                            </i>
                                                        </a>


                                                     </td>

                                                 </tr>
                                              
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                                <div class="container-fluid mt-5 w-100">
                                    <p class="text-right mb-2">Subtotal: <strong>USD  <?php echo e($subtotal); ?></strong></p>
                                    <p class="text-right mb-2">Iva: <strong>USD <?php echo e($iva); ?></strong></p>
                                    <p class="text-right mb-2">Total: <strong> USD<?php echo e($total); ?></strong></p>
    
                                </div>
                            </div>
                            <?php if($clientes->count()==1 && $total!='' && $total!='0' ): ?>
                                <div class="px-4 py-3 bg-gray-50 text-right sm:px-6">
                                    <button type="submit" wire:click="$emit('grabarQuestion',<?php echo e($clientes->count()==1?  $clientes[0]->id : 0); ?>)"
                                        class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                        Guardar
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="px-4 py-3 bg-gray-50 text-right sm:px-6">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => '']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '']); ?>
                                        Guardar
                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                                
                            <?php endif; ?>
                            
                        </div>



                    </div>


                </div>


         <?php $__env->startPush('js'); ?>
        <script src="sweetalert2.all.min.js"></script>
        <script>
            Livewire.on('quitarProducto',key=>
                Swal.fire({ 
                    title: 'Está seguro de elimar el registro?',
                    text: "¡No podrás revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, borrar el registro'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emit('remove',key);                        
                        Swal.fire(
                        'Biormed!',
                        'El registro se borró.',
                        'success'
                        )
                    }
                })
            )
        </script>

<script>
    Livewire.on('grabarQuestion',val=>
        Swal.fire({
            title: 'Está seguro de guardar el pedido?',
            text: "El administrador deberá cerrar el pedido",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si guardar!'
        }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('grabar',val);                        
                Swal.fire(
                    'Guardar!',
                    'Su pedido se almacenó con éxito.',
                    'success'
                )                
            }
        })
    )
</script>



    <?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/create-pedido.blade.php ENDPATH**/ ?>