<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <div style="float: right;">
            <img src= "./images/biormed_logo.jpg" width="200">
            </div>
      <h3>BIORMED</h3>
      <h3> Traslado de productos</h3> 
      <strong>Código: </strong> <?php echo e($codigo); ?> <br/>
      <strong>Decripcion: </strong><?php echo e($nombre); ?> <br/>
      <strong>Origen: </strong> <?php echo e($origen); ?> <br/>
      <strong>Destino: </strong> <?php echo e($destino); ?> <br/>
      <strong>Estado: </strong> <?php echo e($estado); ?> <br/>
      <br/> 
          <?php echo e(now()); ?>        
    <hr/>
    
    
    <table style="border: 1px solid black;  border-collapse: collapse;">
        <tr style="border: 1px solid black;">   
            <td style="border: 1px solid black;"><strong> # </strong></td>         
            <td style="border: 1px solid black;"><strong> id </strong></td>
                    
            <td style="border: 1px solid black;"><strong> Código </strong></td>
                  
            <td style="border: 1px solid black;"><strong> Nomvre </strong></td>
                   
            <td style="border: 1px solid black;"><strong> Cantidad </strong></td>

        </tr>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td style="border: 1px solid black;"><?php echo e($key); ?></td>
            <td style="border: 1px solid black;"><?php echo e($item['producto_id']); ?></td>
            <td style="border: 1px solid black;"><?php echo e($item['producto_codigo']); ?></td>
             <td style="border: 1px solid black;"><?php echo e($item['producto_nombre']); ?></td>
             <td style="border: 1px solid black;"><?php echo e($item['cantidad']); ?></td>
                                                       
         </tr>                           
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
 </body>
    
   
</html><?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/trasladopdf.blade.php ENDPATH**/ ?>