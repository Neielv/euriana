<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Ingreso de pedidos')); ?>

            
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <!-- This example requires Tailwind CSS v2.0+ -->
        <div class="px-6  py-6 flex items-center">
            <div class="flex items-center px-2">
                <samp>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'px-2']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'px-2']); ?>
                        Mostrar 
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>                    
                </samp>

                <select wire:model="cant" class="relative w-full bg-white border border-gray-300 rounded-md shadow-sm pl-3 pr-10 py-2 text-left cursor-default focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" aria-haspopup="listbox" aria-expanded="true" aria-labelledby="listbox-label">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'mx-2']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-2']); ?>
                    Ordenes
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => []]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'mx-4','type' => 'text','wire:model' => 'search','placeholder' => 'Ingrese un nombre']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-4','type' => 'text','wire:model' => 'search','placeholder' => 'Ingrese un nombre']); ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <div class="min-w-min px-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'irAcrearPedido()']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'irAcrearPedido()']); ?>
                    Nuevo 
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

               
            </div>
        </div>
        <?php if($pedidos->count()): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                         
                            <th scope="col"
                                class=" cursor-pointer px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                wire:click="order('id')">
                                Código
                                <?php if($sort == 'id'): ?>
                                    <?php if($direction == 'asc'): ?>
                                        <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Cliente
                                <?php if($sort == 'cliente_id'): ?>
                                    <?php if($direction == 'asc'): ?>
                                        <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                                
                            </th>                            
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Fecha
                            </th>
                           <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Total
                            </th> 
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Factura
                            </th> 
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Estado
                            </th> 
                           
                           
                            <th scope="col" class="relative px-6 py-3">
                                <span class="sr-only">Edit</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->id); ?></div>

                                </td>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->cliente->nombre); ?></div>

                                </td>
                                
                               
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e(date('d-m-Y', strtotime($pedido->created_at))); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->total); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->factura); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->estadopedido->nombre); ?></div>
                                </td>

                                

                                <td class="px-6 py-4 whitespace-nowrap ext-sm font-medium flex">
                                    <a class="btn btn-green" wire:click="edit(<?php echo e($pedido); ?>)">
                                        <i class="fas fa-edit">
                                        </i>
                                    </a>
                                    <?php if($pedido->estadopedido_id==1): ?>
                                        <?php if(auth()->user()->rol_id==1): ?>
                                        <!--   
                                        <a class="btn btn-blue ml-2"  wire:click="$emit('cambiarEstado',<?php echo e($pedido->id); ?>)">
                                                <i class="fas fa-calendar">    
                                                </i>
                                            </a> 
                                        -->
                                        <a class="btn btn-blue ml-2"   wire:click="preClose(<?php echo e($pedido); ?>)">
                                            <i class="fas fa-calendar">    
                                            </i>
                                        </a> 
                                                  
                                    
                                    <a class="btn btn-red ml-2" wire:click="undo(<?php echo e($pedido); ?>)">
                                        <i class="fas fa-undo">    
                                        </i>
                                    </a>
                                    <?php endif; ?>   
                                    <?php endif; ?>   
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- More people... -->
                    </tbody>
                </table>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="px-6 py-4">
                <br>
                No se encontraron coincidencias
            </div>
        <?php endif; ?>
        <?php if($pedidos->hasPages()): ?>
            <div class="px-6 py-3">
                <?php echo e($pedidos->links()); ?>

            </div>
        <?php endif; ?>
    </div>
    <!--MODAL PARA EDITAR / IMPRIMIR-->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'open_edit']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'open_edit']); ?>
            
             <?php $__env->slot('title', null, []); ?> 
                
                    Pedido Nº: <?php echo e($pedido_id); ?>

                
             <?php $__env->endSlot(); ?>       
             <?php $__env->slot('content', null, []); ?> 
                <?php if($pedidos->count()): ?>
                <div class="mb-4">
                    <strong>Cédula: </strong> <?php echo e($cliente_ci); ?>                
                </div>  
                <div class="mb-4">
                    <strong>Nombre: </strong> <?php echo e($cliente_nombre); ?>                
                </div>              
                <div class="mb-4">
                    <strong>Teléfono: </strong> <?php echo e($cliente_telefono); ?>                
                </div>  
                <div class="mb-4">
                    <strong>e-mail: </strong> <?php echo e($cliente_email); ?>                
                
                </div> 
                <div class="mb-4">
                    <strong>Nota de devolución: </strong> <?php echo e($numDevolucion); ?>                
                
                </div> 
                <div class="mb-4">
                    <strong>Factura: </strong> <?php echo e($numFactura); ?>                
                
                </div> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <td>
                                <strong>CANT.<strong>
                                </td>
                                <td>
                                <strong> PRODUCTO</strong>
                                </td>
                                <td>
                                <strong> PRECIO</strong>
                                </td>
                                <td>
                                    <strong> SUB TOTAL</strong>
                                </td>                            
                            </tr>
                        </thead>
                        <tbody>
                        
                            <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                    
                                                
                                                    <tr>
                                                        <td><?php echo e($item['cantidad']); ?></td>
                                                        <td><?php echo e($item['nombre']); ?></td>
                                                        <td><?php echo e($item['precio']); ?></td>
                                                        <td><?php echo e($item['subtotal']); ?></td>
                                                        
                                                    </tr>
                                                
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="3" style="text-align:right; padding-right: 22px;"><strong> Subtotal</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($subtotal); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align:right; padding-right: 22px;"><strong>Iva</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($iva); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align:right; padding-right: 22px;"><strong>Total</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($total); ?></td>
                            </tr>
                        </tbody>
                    </table>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>            
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('footer', null, []); ?> 
                <?php if($pedidos->count()): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => '$set(\'open_edit\',false)']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_edit\',false)']); ?>
                        Cancelar
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>                
                    
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'pdf('.e($pedido).')','class' => 'disabled:pacity-25']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'pdf('.e($pedido).')','class' => 'disabled:pacity-25']); ?>
                            Imprimir
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!--FIN MODAL PARA EDITAR-->
    <!--MODAL DE DEVOLUCIÓN-->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'open_undo']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'open_undo']); ?>
            
             <?php $__env->slot('title', null, []); ?> 
                
                    Devolución de Pedido Nº: <?php echo e($pedido_id); ?>

                
             <?php $__env->endSlot(); ?>       
             <?php $__env->slot('content', null, []); ?> 
                <?php if($pedidos->count()): ?>
                <div class="mb-4">
                    <strong>Cédula: </strong> <?php echo e($cliente_ci); ?>                
                </div>  
                <div class="mb-4">
                    <strong>Nombre: </strong> <?php echo e($cliente_nombre); ?>                
                </div>              
                <div class="mb-4">
                    <strong>Teléfono: </strong> <?php echo e($cliente_telefono); ?>                
                </div>  
                <div class="mb-4">
                    <strong>e-mail: </strong> <?php echo e($cliente_email); ?>   
                </div> 
                <div class="mb-4">
                    <strong>Nota de devolucón: </strong> 
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'mx-4 w-2','style' => 'width:80px;','type' => 'text','wire:model.defer' => 'nota_devolucion','placeholder' => '00000']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-4 w-2','style' => 'width:80px;','type' => 'text','wire:model.defer' => 'nota_devolucion','placeholder' => '00000']); ?>
                                                                                                                                                                                            
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  
                </div> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <td>
                                <strong>CANT.<strong>
                                </td>
                                <td>
                                    <strong>DEV.<strong>
                                </td>                            
                                <td>
                                <strong> PRODUCTO</strong>
                                </td>
                                <td>
                                <strong> PRECIO</strong>
                                </td>
                                <td>
                                    <strong> SUB TOTAL</strong>
                                </td>                            
                            </tr>
                        </thead>
                        <tbody>
                        
                            <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                   
                                                
                                                    <tr>
                                                        <td><?php echo e($item['cantidad']); ?></td>
                                                        <td>
                                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'mx-4 w-2','style' => 'width:60px;','type' => 'text','wire:model.defer' => 'orderProduct.'.e($key).'.undo','placeholder' => '0']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-4 w-2','style' => 'width:60px;','type' => 'text','wire:model.defer' => 'orderProduct.'.e($key).'.undo','placeholder' => '0']); ?>
                                                                                                                                                                                            
                                                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($item['nombre']); ?></td>
                                                        <td><?php echo e($item['precio']); ?></td>
                                                        <td><?php echo e($item['subtotal']); ?></td>                                                     
                                                    </tr>
                                                
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4" style="text-align:right; padding-right: 22px;"><strong> Subtotal</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($subtotal); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4" style="text-align:right; padding-right: 22px;"><strong>Iva</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($iva); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4" style="text-align:right; padding-right: 22px;"><strong>Total</strong></td>
                                <td style="text-align:left; margin-right: 8px;">USD <?php echo e($total); ?></td>
                            </tr>
                        </tbody>
                    </table>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>            
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('footer', null, []); ?> 
                <?php if($pedidos->count()): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => '$set(\'open_undo\',false)']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_undo\',false)']); ?>
                        Cancelar
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php if($editable): ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'saveUndo()','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'disabled:pacity-25']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'saveUndo()','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'disabled:pacity-25']); ?>
                            Guardar
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>               
                    <?php endif; ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!--FIN DE MODAL DE DEVOCLUCIÓN-->
    <!--MODAL DE CERRAR-->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'open_close']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'open_close']); ?>            
         <?php $__env->slot('title', null, []); ?>             
                Cerrar el pedido de Pedido Nº: <?php echo e($pedido_id); ?>            
         <?php $__env->endSlot(); ?>       
         <?php $__env->slot('content', null, []); ?> 
            <?php if($pedidos->count()): ?>
            <div class="mb-4">
                <strong>Cédula: </strong> <?php echo e($cliente_ci); ?>                
            </div>  
            <div class="mb-4">
                <strong>Nombre: </strong> <?php echo e($cliente_nombre); ?>                
            </div>              
            <div class="mb-4">
                <strong>Teléfono: </strong> <?php echo e($cliente_telefono); ?>                
            </div>  
            <div class="mb-4">
                <strong>e-mail: </strong> <?php echo e($cliente_email); ?>   
            </div> 
            <div class="mb-4">
                <strong>Factura: </strong> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'mx-4 w-2','style' => 'width:80px;','type' => 'text','wire:model.defer' => 'nota_devolucion','placeholder' => '00000']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mx-4 w-2','style' => 'width:80px;','type' => 'text','wire:model.defer' => 'nota_devolucion','placeholder' => '00000']); ?>
                                                                                                                                                                                        
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  
            </div> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <td>
                            <strong>CANT.<strong>
                            </td>                                                        
                            <td>
                            <strong> PRODUCTO</strong>
                            </td>
                            <td>
                            <strong> PRECIO</strong>
                            </td>
                            <td>
                                <strong> SUB TOTAL</strong>
                            </td>                            
                        </tr>
                    </thead>
                    <tbody>
                    
                        <?php $__currentLoopData = $orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                                <tr>
                                                    <td><?php echo e($item['cantidad']); ?></td>                                                    
                                                    <td><?php echo e($item['nombre']); ?></td>
                                                    <td><?php echo e($item['precio']); ?></td>
                                                    <td><?php echo e($item['subtotal']); ?></td>                                                     
                                                </tr>                                            
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4" style="text-align:right; padding-right: 22px;"><strong> Subtotal</strong></td>
                            <td style="text-align:left; margin-right: 8px;">USD <?php echo e($subtotal); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align:right; padding-right: 22px;"><strong>Iva</strong></td>
                            <td style="text-align:left; margin-right: 8px;">USD <?php echo e($iva); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="text-align:right; padding-right: 22px;"><strong>Total</strong></td>
                            <td style="text-align:left; margin-right: 8px;">USD <?php echo e($total); ?></td>
                        </tr>
                    </tbody>
                </table>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>            
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('footer', null, []); ?> 
            <?php if($pedidos->count()): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => '$set(\'open_close\',false)']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_close\',false)']); ?>
                    Cancelar
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if($editable): ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'saveClose()','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'disabled:pacity-25']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'saveClose()','wire:loading.attr' => 'disabled','wire:target' => 'save','class' => 'disabled:pacity-25']); ?>
                        Guardar
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>               
                <?php endif; ?>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!--FIN DE MODAL DE CERRAR-->
    <?php $__env->startPush('js'); ?>
        <script src="sweetalert2.all.min.js"></script>
        <script>
            Livewire.on('cambiarEstado', PedidoId =>
                Swal.fire({ 
                title: 'Está seguro de cerrar el pedido?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, cerrar el pedido'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emitTo('show-pedidos', 'cerrarPedido', PedidoId);
                        Swal.fire(
                        'Biormed!',
                        'Pedido cerrado.',
                        'success'
                        )
                    }
                })
            )
        </script>
    <?php $__env->stopPush(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/show-pedidos.blade.php ENDPATH**/ ?>