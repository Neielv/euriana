<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <div style="float: right;">
            <img src= "./images/biormed_logo.jpg" width="200">
            </div>
      <h3>BIORMED</h3>
       <h3> INVENTARIO</h3>  
       <?php echo e(now()); ?>        
    <hr/>
    
 
   
   <table style="border: 1px solid black;  border-collapse: collapse;">
    <tr style="border: 1px solid black;">            
        <td style="border: 1px solid black;"><strong> # </strong></td>
                
        <td style="border: 1px solid black;"><strong> Porducto </strong></td>
              
        <td style="border: 1px solid black;"><strong> Descripcion </strong></td>
               
        <td style="border: 1px solid black;"><strong> Bodega </strong></td>

        <td style="border: 1px solid black;"><strong> Stock </strong></td>
    </tr>
    <?php $__currentLoopData = $datos_detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            
                                <td style="border: 1px solid black;">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->indice); ?></div>
                                </td>
                                <td style="border: 1px solid black;">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->codigo); ?></div>
                                </td>
                                <td style="border: 1px solid black;">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->producto); ?></div>
                                </td>
                                <td style="border: 1px solid black;">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->ciudad); ?></div>
                                </td>
                                <td style="border: 1px solid black;">
                                    <div class="text-sm text-gray-900"> <?php echo e($pedido->stock); ?></div>
                                </td>
                                
                            
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
</table>
    
 </body>
    
   
</html><?php /**PATH C:\xampp\htdocs\biormed\resources\views/livewire/inventariopdf.blade.php ENDPATH**/ ?>